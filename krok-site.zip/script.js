const darkModeButton = document.querySelector('.dark-mode');//Selektuje se klasa "dark-mode" čime se obuhvata dugme za tamni režim na svakoj stranici 
const darkModeButtonState = localStorage.getItem('darkModeButtonState'); /*Čita se ključ na "localStorage" pod nazivom "darkModeButtonState" i čuva u
konstanti "darkModeButtonState". */

// Ispis u konzoli naziva HTML datoteke i koja je stanje za ključ "darkModeButtonState". Ovo je vid provere u konzoli kako se kreće izvršavanje koda.
console.log(`Početno stanje dugmeta na stranici ${window.location.pathname} je ${localStorage.getItem('darkModeButtonState')}`);
// Ovaj vid dibag ispisa u konzoli odvajam od drugih radnih elemenata koda komentarima kako bi kod bio čitljiviji i pregledniji.

document.addEventListener('DOMContentLoaded', initMode); /* Nadgledanje učitavanja sadržaja DOM-a i pozivanje funkcije "initMode" kojom se obrađuje
dati događaj učitavanja i vrše se provere i inicijalizacija režima dugmeta odn. prikaza. */

darkModeButton.addEventListener('click', changeMode); /* Nadgledanje događaja klika mišem na dugme putem objekta "darkModeButton" i pozivanje
obrađivača "changeMode", funkcije kojom se vrši promena stanja dugmeta, a samim tim i prikaza. */

function initMode(){ //funkcija kojom se postavlja početno stanje (inicijalizuje) dugmeta, odn. prikaza.
    const state = localStorage.getItem('darkModeButtonState');

    console.log(`Pocetno stanje iz funkcije initMode() kada se ucita DOM > ${state}`);

    if (state === null || state === undefined) {
        localStorage.setItem('darkModeButtonState','night');
        state = localStorage.getItem('darkModeButtonState');

        console.log(`Provera kada je stanje bilo null, sada je stanje > ${localStorage.getItem('darkModeButtonState')}`);
    }
    if (state === 'day') {
        document.body.style.backgroundColor = 'white';
        darkModeButton.textContent = "Dnevni režim";
        localStorage.setItem('darkModeButtonState','day');

        console.log(`${darkModeButton.textContent}; izvrsena je funk. changeMode()`);
        console.log(`${localStorage.getItem('darkModeButtonState')}; izvrsena je funk. changeMode() i trebalo bi da je dnevni rezim`);
        
    } else if (state === 'night'){
        document.body.style.backgroundColor = 'black';
        darkModeButton.textContent = "Noćni režim";
        localStorage.setItem('darkModeButtonState','night');

        console.log(`${localStorage.getItem('darkModeButtonState')}; izvrsena je funk. changeMode() i trebalo bi da je nocni rezim`);
    }
}

function changeMode(){
    const state = localStorage.getItem('darkModeButtonState');
    if (state === 'night') {
        document.body.style.backgroundColor = 'white';
        darkModeButton.textContent = "Dnevni režim";
        localStorage.setItem('darkModeButtonState','day');
        
        console.log(`${darkModeButton.textContent}; izvrsena je funk. changeMode()`);
        console.log(`${localStorage.getItem('darkModeButtonState')}; izvrsena je funk. changeMode() i trebalo bi da je dnevni rezim`);
    } else if (state === 'day'){
        document.body.style.backgroundColor = 'black';
        darkModeButton.textContent = "Noćni režim";
        localStorage.setItem('darkModeButtonState','night');
        console.log(`${localStorage.getItem('darkModeButtonState')}; izvrsena je funk. changeMode() i trebalo bi da je nocni rezim`);
    }
    
}

// Ovaj komentar je dodao Copilot: This IIFE dynamically loads the weather widget script from weatherwidget.io 
    !function(d, s, id) {
    let js, fjs = d.getElementsByTagName(s)[0];
    if(!d.getElementById(id))
        {js = d.createElement(s);
            js.id = id;
            js.src = 'https://weatherwidget.io/js/widget.min.js';
            fjs.parentNode.insertBefore(js, fjs);
        }
    }
        (document, 'script', 'weatherwidget-io-js');


